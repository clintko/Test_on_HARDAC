#include <stan/model/model_functional.hpp>
#include <gtest/gtest.h>
